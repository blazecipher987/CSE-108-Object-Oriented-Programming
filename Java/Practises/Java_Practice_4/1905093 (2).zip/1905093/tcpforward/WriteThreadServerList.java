package tcpforward;

import util.NetworkUtil;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;



    class WriteThreadClientList implements Runnable {

        private Thread thr;
        private NetworkUtil networkUtil;
        private List<String> list;
        String name;

        public WriteThreadClientList(NetworkUtil networkUtil, List list) {
            this.networkUtil = networkUtil;
            this.name = name;
            this.thr = new Thread(this);
            this.list = list;
            thr.start();
        }

        public void run() {
            try {
                Scanner input = new Scanner(System.in);
                while (true) {
                    String from = name;
                    System.out.print("Enter name of the client to send: ");
                    String to = input.nextLine();
                    System.out.print("Enter the message: ");
                    String text = input.nextLine();
                    Message message = new Message();
                    message.setFrom(from);
                    message.setTo(to);
                    message.setText(text);
                    networkUtil.write(message);
                }
            } catch (Exception e) {
                System.out.println(e);
            } finally {
                try {
                    networkUtil.closeConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

