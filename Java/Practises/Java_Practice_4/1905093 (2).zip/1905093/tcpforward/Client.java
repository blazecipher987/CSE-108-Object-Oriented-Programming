package tcpforward;

import util.NetworkUtil;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Client {
    NetworkUtil networkUtilMain;
    List<String> clientList;

    public Client(String serverAddress, int serverPort) {
        try {
            System.out.print("Enter name of the client: ");
            Scanner scanner = new Scanner(System.in);
            String clientName = scanner.nextLine();
            NetworkUtil networkUtil = new NetworkUtil(serverAddress, serverPort);
            networkUtil.write(clientName);
            new ReadThreadClient(networkUtil);
            new WriteThreadClient(networkUtil, clientName);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Client(){

    }

    public void connect() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;
        //Client client = new Client(serverAddress, serverPort);
        System.out.print("Enter name of the client: ");
        Scanner scanner = new Scanner(System.in);
        String clientName = scanner.nextLine();
        NetworkUtil networkUtil = new NetworkUtil(serverAddress, serverPort);
        setNetworkUtilMain(networkUtil);
        networkUtil.write(clientName);
    }

    public void sendMessage() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;
        System.out.print("Enter name of the client: ");
        Scanner scanner = new Scanner(System.in);
        String clientName = scanner.nextLine();
        NetworkUtil networkUtil = new NetworkUtil(serverAddress, serverPort);
        networkUtil.write(clientName);
        new ReadThreadClient(networkUtil);
        new WriteThreadClient(networkUtil, clientName);
    }

    public void getList(){

    }

    public void Broadcast() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;
        for (int i = 0; i < clientList.size(); i++) {
            NetworkUtil networkUtil = new NetworkUtil(serverAddress, serverPort);
            networkUtil.write(clientList.get(i));
            new ReadThreadClient(networkUtil);
            new WriteThreadClient(networkUtil, clientList.get(i));
        }

    }

    public NetworkUtil getNetworkUtilMain() {
        return networkUtilMain;
    }


    public void setNetworkUtilMain(NetworkUtil networkUtilMain) {
        this.networkUtilMain = networkUtilMain;
    }

    public static void main(String args[]) throws IOException {

        Client client = new Client();

        System.out.println("1. Connect\n" + "2. GetList\n" + "3.Send Message\n" + "4.Broadcast");
        while (true){
            Scanner sc = new Scanner(System.in);
            int n = sc.nextInt();

            if(n==1){
                client.connect();
            }

            if(n==2){
                client.getList();
            }

            if(n==3){
                client.sendMessage();
            }
            if(n==4){
                client.Broadcast();
            }
        }

    }
}


