package util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


//So basically every server and client have input & output streams. so what this class does is create those streams automatically
//for each of the clients and server
public class NetworkUtil {
    private Socket socket;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;

    public NetworkUtil(String s, int port) throws IOException { //This constructor is for the client
        this.socket = new Socket(s, port); // s is for the IP address
        oos = new ObjectOutputStream(socket.getOutputStream());
        ois = new ObjectInputStream(socket.getInputStream());
    }

    public NetworkUtil(Socket s) throws IOException {//this constructor is used for ht server
        this.socket = s;
        oos = new ObjectOutputStream(socket.getOutputStream());
        ois = new ObjectInputStream(socket.getInputStream());
    }

    public Object read() throws IOException, ClassNotFoundException {
        return ois.readUnshared(); //instead of ois.readObject(), we use this one
    }

    public void write(Object o) throws IOException {
        oos.writeUnshared(o); //instead of ois.writeObject(o), we use this one
    }

    public void closeConnection() throws IOException { //close the input output streams
        ois.close();
        oos.close();
    }
}

