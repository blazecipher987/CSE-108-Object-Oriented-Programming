public class Club {
    private int id;
    private String name;
    private Player[] players;
    // add your code here
    private int playerCount;
    private int curr;

	// you are not allowed to write any other constructor
    public Club() {
        this.players = new Player[11];
        this.playerCount=0;
        this.curr=0;
    }

	public double getSalary() {
        double total = 0;
        for (int i = 0; i < playerCount; i++) {
            total += players[i].getSalary();
        }
        return total;
    }
	
	// add your code here

    public void addPlayer(Player pl){
        players[playerCount].setSalary(pl.getSalary());
        players[playerCount].setName(pl.getName());
        players[playerCount].setNumber(pl.getNumber());
        playerCount++;
    }

    Player getMaxSalaryPlayer() {
        double max = 0;
        for (int i = 0; i < playerCount; i++) {
            if (players[i].getSalary() > max) {
                max = players[i].getSalary();
                curr = i;
            }
        }
        return players[curr];
    }


    public void setId(int x){
        id = x;
    }
    public int getId(){
        return id;
    }

    public void setName(String str){
        name = str;
    }
    public String getName(){
        return name;
    }

}